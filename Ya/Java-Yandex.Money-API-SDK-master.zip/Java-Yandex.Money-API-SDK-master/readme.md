## Project moved to official [java](https://github.com/yandex-money/yandex-money-sdk-java) and [android](https://github.com/yandex-money/yandex-money-sdk-java) repositories.

### This repo is no longer supported
