package ru.yandex.money.droid;

class Consts {      
        
    public static final String WAIT = "Пожалуйста, подождите";
    
    public static String USER_AGENT = "yamodroid";    
}