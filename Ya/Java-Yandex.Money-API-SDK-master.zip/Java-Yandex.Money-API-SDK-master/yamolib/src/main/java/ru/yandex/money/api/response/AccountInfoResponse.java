package ru.yandex.money.api.response;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Класс для возврата результата метода accountInfo.
 * Показывает номер счета, текущий баланс и код валюты пользователя
 * (возможные значения кода валюты: 643 - российский рубль).
 * @author dvmelnikov
 */

public class AccountInfoResponse implements Serializable {

    private static final long serialVersionUID = -5030821635331803325L;
    
    private String account;
    private BigDecimal balance;
    private String currency;
    private Boolean identified;
    private String account_type;

    private AccountInfoResponse() {
    }

    /**
     *
     * @return номер счета пользователя
     */
    public String getAccount() {
        return account;
    }

    /**
     *
     * @return остаток на счете пользователя
     */
    public BigDecimal getBalance() {
        return balance;
    }

    /**
     *
     * @return Код валюты счета пользователя. Всегда 643 (рубль РФ по
     * стандарту ISO 4217).
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * @return true, если пользователь идентифицирован в системе Яндекс.Денег
     */
    public Boolean isIdentified() {
        return identified;
    }

    /**
     * @return Тип счета в системе Яндекс.Денег. "personal" либо "professional"
     */
    public String getAccountType() {
        return account_type;
    }

    @Override
    public String toString() {
        return "AccountInfoResponse{" +
                "account='" + account + '\'' +
                ", balance=" + balance +
                ", currency='" + currency + '\'' +
                ", identified=" + identified +
                ", account_type='" + account_type + '\'' +
                '}';
    }
}
