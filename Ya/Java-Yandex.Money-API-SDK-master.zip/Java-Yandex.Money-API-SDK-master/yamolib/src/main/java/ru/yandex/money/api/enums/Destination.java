package ru.yandex.money.api.enums;

/**
 * @author dvmelnikov
 */

public enum Destination {
    toAccount,
    toPattern
}
