package ru.yandex.money.api.response.util;

/**
 * <p/>
 * <p/>
 * Created: 27.11.13 7:53
 * <p/>
 *
 * @author OneHalf
 */
public interface PaymentErrorCode {

    String getCode();
}
