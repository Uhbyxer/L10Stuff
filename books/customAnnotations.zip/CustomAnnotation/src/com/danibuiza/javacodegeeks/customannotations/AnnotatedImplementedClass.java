package com.danibuiza.javacodegeeks.customannotations;

public class AnnotatedImplementedClass implements AnnotatedInterface
{

    @Override
    public void oneMethod()
    {

    }

}
