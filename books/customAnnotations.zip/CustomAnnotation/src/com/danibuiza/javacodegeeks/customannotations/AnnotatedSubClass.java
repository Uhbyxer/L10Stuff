package com.danibuiza.javacodegeeks.customannotations;

public class AnnotatedSubClass extends AnnotatedSuperClass
{

    @Override
    public void oneMethod(){
        
    }
    
}
